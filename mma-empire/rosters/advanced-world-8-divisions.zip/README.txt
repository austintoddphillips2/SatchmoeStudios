MMA Empire world pack v1
New single-player worlds only. Importing permanently disables new achievements for that save.

Edit the CSVs in a spreadsheet and save as UTF-8 CSV. Keep manifest.json and all CSVs together at the ZIP root or in a single folder; re-ZIP these files after editing. Do not rename headers or add unchecked columns. Blank optional fighter fields use normal generated defaults; core fields are required. IDs are stable references within this world pack, not IDs from another save.

Selected fighter fields: boxing, kickboxing, wrestling, jiujitsu, stamina, durability, style, popularity, energy, morale, hometown_city_id, peak_start, peak_end, personality, motivation_1, motivation_2, sensitivity, communication, trait_potential, trait_marketability, trait_charisma, trait_socialMediaDraw, trait_localHeroBonus, trait_trashTalk, trait_rivalryAppeal, trait_consistency, trait_discipline, trait_moraleVolatility, trait_contractDemands, trait_loyalty, trait_ego, trait_injuryProneness, trait_developmentRate, trait_finishingInstinct, trait_clutch, trait_weightCutRisk, fights_left, contract_years_left, show_pay, win_bonus, promised_role, secondary_division

companies.csv configures the existing promotion IDs listed in company-ids.csv. player is your promotion. Starting cash is dollars 0–1,000,000,000,000; blank retains the default. Headquarters must be a city ID in cities.csv. Owner names are optional (80 characters each). Company names/new promotion IDs are not imported by this format. Local promotion IDs are listed for fighter placement; local promotion finances and owners remain generated.

markets.csv uses company_id, city_id, fans (0–1,000,000,000), awareness and loyalty (0–100). These are starting audiences, not hosting licenses.

history.csv: one row per fighter's previous bout. fighter_id must exist in fighters.csv; opponent_id may be blank for an external opponent, but opponent_name is required. Use W/L/D and weeks_before_start (1–10,000), method text, round 1–20, and time 0:00–5:00. Prior history does not become your new promotion's organization record or generate financial receipts. Partial prior history is allowed; its W/L/D totals cannot exceed the fighter's record. Unlisted fights remain record-only.

titles.csv: one row per company/division, with champion_id and optional interim_champion_id from fighters.csv. Blank means vacant. CPU companies support full titles only. Champions must belong to that company and be eligible for the division. Two-division champions need secondary_division.

Replace rosters affects companies represented by fighter rows, including free-agent. Unrepresented rosters keep generated fighters. Replace company selection uses only CPU company IDs in companies.csv. Otherwise imported CPU IDs are added to normal difficulty defaults. Replace audiences clears generated fans/awareness/loyalty for companies represented by markets.csv before applying its rows; other companies retain generated audiences.

Examples are demonstration rows, not a balanced playable world. Add fighters before creating your career. Existing careers can export a starting-world pack, but advanced packs cannot rewrite an existing career.
